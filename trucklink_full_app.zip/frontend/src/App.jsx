import React, { useState } from 'react';
import PassengerHome from './pages/PassengerHome';
import DriverHome from './pages/DriverHome';
import AdminHome from './pages/AdminHome';

export default function App(){
  const [view, setView] = useState('passenger');
  return (
    <div style={{fontFamily:'Inter, system-ui', padding:20}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1 style={{color:'#0F766E'}}>TruckLink</h1>
        <div>
          <button onClick={()=>setView('passenger')} style={{marginRight:8}}>Passenger</button>
          <button onClick={()=>setView('driver')} style={{marginRight:8}}>Driver</button>
          <button onClick={()=>setView('admin')}>Admin</button>
        </div>
      </header>
      <main style={{marginTop:20}}>
        {view==='passenger' && <PassengerHome />}
        {view==='driver' && <DriverHome />}
        {view==='admin' && <AdminHome />}
      </main>
    </div>
  )
}
