import React from 'react';
export default function AdminHome(){
  return (
    <div>
      <h2>Admin Dashboard (skeleton)</h2>
      <ul>
        <li>Support: view tickets</li>
        <li>Safety: trip replay tools</li>
        <li>Finance: run payouts</li>
        <li>CityOps: launch promos</li>
      </ul>
    </div>
  )
}
