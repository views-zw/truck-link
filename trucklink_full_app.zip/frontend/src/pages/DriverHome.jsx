import React from 'react';
export default function DriverHome(){
  return (
    <div>
      <h2>Driver Dashboard (skeleton)</h2>
      <p>Toggle availability, view bookings, and update location.</p>
    </div>
  )
}
