import React, {useEffect, useState} from 'react';
import axios from 'axios';
export default function PassengerHome(){
  const [drivers, setDrivers] = useState([]);
  const [selected, setSelected] = useState(null);
  useEffect(()=>{ axios.get('/api/drivers/active').then(r=>setDrivers(r.data)).catch(()=>{}); },[]);
  function requestBooking(){
    const body = { passengerId: 'demo-passenger', driverId: selected.id, pickupLat: -17.8, pickupLng: 31.0, dropoffLat: -17.9, dropoffLng: 31.1, price: 50 };
    axios.post('/api/trips/request', body).then(r=>{ alert('Booking requested: '+r.data.id); }).catch(e=>{ alert('error'); });
  }
  return (
    <div>
      <h2>Active Drivers</h2>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
        {drivers.map(d=> (
          <div key={d.id} style={{border:'1px solid #eee', padding:12, borderRadius:8}}>
            <img src={d.imageUrl} alt='' style={{width:'100%', height:120, objectFit:'cover', borderRadius:6}} />
            <h3 style={{marginTop:8}}>{d.userId} — {d.vehicleMake} {d.vehicleModel}</h3>
            <div>Class: {d.vehicleClass}</div>
            <div>Seats: {d.seats}</div>
            <div style={{marginTop:8}}>
              <button onClick={()=>setSelected(d)} style={{background:'#FF7A5A', color:'#fff', padding:'8px 12px', borderRadius:6}}>Select</button>
            </div>
          </div>
        ))}
      </div>
      {selected && (
        <div style={{position:'fixed', right:20, bottom:20, background:'#fff', padding:16, boxShadow:'0 4px 12px rgba(0,0,0,0.08)'}}>
          <h4>Confirm hire: {selected.vehicleMake} {selected.vehicleModel}</h4>
          <button onClick={requestBooking} style={{background:'#0F766E', color:'#fff', padding:'8px 12px', borderRadius:6}}>Request Booking</button>
        </div>
      )}
    </div>
  )
}
