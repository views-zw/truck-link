Infra notes: For production, use RDS for Postgres, ElastiCache for Redis, S3 for storage.
Deploy backend services on ECS/Fargate or Kubernetes. Use ALB + ACM for TLS.
