import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import { PrismaClient } from '@prisma/client';
import authRouter from './routes/auth';
import usersRouter from './routes/users';
import driversRouter from './routes/drivers';
import trucksRouter from './routes/trucks';
import tripsRouter from './routes/trips';
import adminRouter from './routes/admin';
dotenv.config();
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.FRONTEND_URL || '*' } });
const prisma = new PrismaClient();
app.use(cors());
app.use(express.json());
app.get('/', (req,res)=> res.send('TruckLink backend running'));

app.use('/api/auth', authRouter);
app.use('/api/users', usersRouter);
app.use('/api/drivers', driversRouter);
app.use('/api/trucks', trucksRouter);
app.use('/api/trips', tripsRouter);
app.use('/api/admin', adminRouter);

// Socket.io stub for driver location updates
io.on('connection', (socket) => {
  console.log('socket connected', socket.id);
  socket.on('driver:location', (data) => {
    // broadcast to interested clients in prod would be optimized
    io.emit('driver:update', data);
  });
});

const port = process.env.PORT || 4000;
server.listen(port, ()=> console.log(`Server started on ${port}`));
