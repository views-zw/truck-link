import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { authGuard, requireRole } from '../utils/auth';
import { logAudit } from '../utils/audit';
const prisma = new PrismaClient();
const router = Router();

// Support: view user and trip read-only
router.get('/users/:id', authGuard, requireRole('SUPPORT'), async (req,res)=>{
  const u = await prisma.user.findUnique({ where: { id: req.params.id } });
  await logAudit(req.user.id, 'view_user', { targetId: req.params.id });
  res.send(u);
});

// Safety: ban user
router.post('/ban/:id', authGuard, requireRole('SAFETY'), async (req,res)=>{
  const u = await prisma.user.update({ where: { id: req.params.id }, data: { role: 'BANNED' } });
  await logAudit(req.user.id, 'ban_user', { targetId: req.params.id });
  res.send(u);
});

// Finance: trigger payout (placeholder)
router.post('/payouts/run', authGuard, requireRole('FINANCE'), async (req,res)=>{
  // placeholder for payout worker
  await logAudit(req.user.id, 'run_payouts', {});
  res.send({ ok: true });
});

export default router;
