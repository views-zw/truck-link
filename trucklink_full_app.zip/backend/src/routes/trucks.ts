import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { authGuard } from '../utils/auth';
const prisma = new PrismaClient();
const router = Router();

router.post('/', authGuard, async (req,res)=>{
  const { driverId, className, capacity, gmvMin, gmvMax, imageUrl } = req.body;
  const t = await prisma.truck.create({ data: { driverId, class: className, capacity: Number(capacity), gmvMin: Number(gmvMin), gmvMax: Number(gmvMax), imageUrl } });
  res.send(t);
});

router.get('/', async (req,res)=>{
  const q = await prisma.truck.findMany({ take: 200 });
  res.send(q);
});

export default router;
