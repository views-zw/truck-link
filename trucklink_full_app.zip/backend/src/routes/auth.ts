import { Router } from 'express';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';
dotenv.config();
const prisma = new PrismaClient();
const router = Router();
// Passenger/Driver simple registration (phone and name)
router.post('/register', async (req,res)=>{
  const { phone, name, role } = req.body;
  if(!phone) return res.status(400).send({error:'phone required'});
  const user = await prisma.user.create({ data: { phone, name, role: role || 'PASSENGER' } });
  const token = jwt.sign({ id: user.id, phone: user.phone, role: user.role }, process.env.JWT_SECRET || 'dev', { expiresIn: '7d' });
  res.send({ user, token });
});

router.post('/login', async (req,res)=>{
  const { phone } = req.body;
  if(!phone) return res.status(400).send({error:'phone required'});
  const user = await prisma.user.findUnique({ where: { phone } });
  if(!user) return res.status(404).send({ error: 'user not found' });
  const token = jwt.sign({ id: user.id, phone: user.phone, role: user.role }, process.env.JWT_SECRET || 'dev', { expiresIn: '7d' });
  res.send({ user, token });
});

export default router;
