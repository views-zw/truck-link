import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { authGuard } from '../utils/auth';
const prisma = new PrismaClient();
const router = Router();

router.post('/profile', authGuard, async (req,res)=>{
  const { userId, vehicleMake, vehicleModel, vehiclePlate, vehicleClass, seats, imageUrl } = req.body;
  const d = await prisma.driver.create({ data: { userId, vehicleMake, vehicleModel, vehiclePlate, vehicleClass, seats: Number(seats||1), currentLat: null, currentLng: null, docs: {}, imageUrl } });
  res.send(d);
});

router.get('/active', async (req,res)=>{
  const drivers = await prisma.driver.findMany({ where: { active: true }, take: 100 });
  res.send(drivers);
});

router.post('/:id/availability', authGuard, async (req,res)=>{
  const { id } = req.params; const { active } = req.body;
  const d = await prisma.driver.update({ where: { id }, data: { active } });
  res.send(d);
});

export default router;
