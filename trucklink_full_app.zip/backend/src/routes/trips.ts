import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { authGuard } from '../utils/auth';
const prisma = new PrismaClient();
const router = Router();

// Passenger requests a trip with driver
router.post('/request', authGuard, async (req,res)=>{
  const { passengerId, driverId, pickupLat, pickupLng, dropoffLat, dropoffLng, price } = req.body;
  const trip = await prisma.trip.create({ data: { passengerId, driverId, pickupLat: Number(pickupLat), pickupLng: Number(pickupLng), dropoffLat: Number(dropoffLat), dropoffLng: Number(dropoffLng), price: Number(price), status: 'REQUESTED' } });
  res.send(trip);
});

router.post('/:id/accept', authGuard, async (req,res)=>{
  const { id } = req.params;
  const t = await prisma.trip.update({ where: { id }, data: { status: 'ACCEPTED', startedAt: new Date() } });
  res.send(t);
});

router.post('/:id/complete', authGuard, async (req,res)=>{
  const { id } = req.params;
  const t = await prisma.trip.update({ where: { id }, data: { status: 'COMPLETED', endedAt: new Date() } });
  res.send(t);
});

router.get('/:id', authGuard, async (req,res)=>{
  const { id } = req.params;
  const t = await prisma.trip.findUnique({ where: { id } });
  res.send(t);
});

export default router;
