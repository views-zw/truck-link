import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { authGuard } from '../utils/auth';
const prisma = new PrismaClient();
const router = Router();
router.get('/', authGuard, async (req,res)=>{
  const users = await prisma.user.findMany({ take: 50 });
  res.send(users);
});
export default router;
