import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
dotenv.config();
export interface AuthRequest extends Request { user?: any }
export function authGuard(req: AuthRequest, res: Response, next: NextFunction){
  const h = req.headers.authorization as string | undefined;
  if(!h) return res.status(401).send({ error: 'missing token' });
  const token = h.split(' ')[1];
  try{ const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev'); req.user = payload; next(); }
  catch(e){ return res.status(401).send({ error: 'invalid token' }); }
}

// Simple RBAC check
export function requireRole(role: string){
  return (req: AuthRequest, res: Response, next: NextFunction)=>{
    if(!req.user) return res.status(401).send({ error: 'not authenticated' });
    if(req.user.role !== role && req.user.role !== 'SUPER') return res.status(403).send({ error: 'forbidden' });
    next();
  }
}
