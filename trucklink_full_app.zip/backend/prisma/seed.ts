import { PrismaClient } from '@prisma/client';
const db = new PrismaClient();
async function main(){
  console.log('Seeding...');
  const u1 = await db.user.create({ data: { phone: '+263771111111', name: 'Super Admin', role: 'ADMIN' } });
  await db.adminRole.create({ data: { userId: u1.id, role: 'SUPER' } });
  const p = await db.user.create({ data: { phone: '+263772222222', name: 'Passenger One' } });
  const du = await db.user.create({ data: { phone: '+263773333333', name: 'Driver One', role: 'DRIVER' } });
  const driver = await db.driver.create({ data: { userId: du.id, vehicleMake: 'Isuzu', vehicleModel: 'NMR', vehiclePlate: 'ABC123', vehicleClass: 'Light Commercial', seats: 3, active: true, imageUrl: 'https://images.unsplash.com/photo-1604999562079-9b59aa16862d?auto=format&fit=crop&w=600&q=60' } });
  const truck = await db.truck.create({ data: { driverId: driver.id, class: 'Light Commercial', capacity: 3500, gmvMin: 0, gmvMax: 500, imageUrl: 'https://images.unsplash.com/photo-1604999562079-9b59aa16862d?auto=format&fit=crop&w=600&q=60' } });
  console.log('Seed complete');
}
main().catch(e=>{console.error(e); process.exit(1)}).finally(()=>process.exit());
